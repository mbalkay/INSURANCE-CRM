<?php
/**
 * Data Validation Utilities for Import System
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * TC Kimlik Numarası doğrulama algoritması
 * 
 * @param string $tc_no TC Kimlik numarası
 * @return bool Geçerli ise true
 */
function validate_tc_kimlik($tc_no) {
    // Boş değer kontrolü
    if (empty($tc_no)) {
        return false;
    }
    
    // String'e çevir ve sadece rakamları al
    $tc_no = preg_replace('/[^0-9]/', '', $tc_no);
    
    // 11 haneli olmalı
    if (strlen($tc_no) !== 11) {
        return false;
    }
    
    // İlk hane 0 olamaz
    if ($tc_no[0] === '0') {
        return false;
    }
    
    // Tüm haneler aynı olamaz
    if (preg_match('/^(\d)\1{10}$/', $tc_no)) {
        return false;
    }
    
    // Algoritma kontrolü
    $digits = str_split($tc_no);
    
    // İlk 10 hanenin toplamı
    $sum_first_10 = 0;
    for ($i = 0; $i < 10; $i++) {
        $sum_first_10 += (int)$digits[$i];
    }
    
    // 11. hane kontrolü
    if (($sum_first_10 % 10) != (int)$digits[10]) {
        return false;
    }
    
    // 10. hane kontrolü
    $sum_odd = 0;  // 1,3,5,7,9. hanelerin toplamı
    $sum_even = 0; // 2,4,6,8. hanelerin toplamı
    
    for ($i = 0; $i < 9; $i++) {
        if ($i % 2 === 0) {
            $sum_odd += (int)$digits[$i];
        } else {
            $sum_even += (int)$digits[$i];
        }
    }
    
    $check_digit = (($sum_odd * 7) - $sum_even) % 10;
    if ($check_digit != (int)$digits[9]) {
        return false;
    }
    
    return true;
}

/**
 * Telefon numarası format doğrulaması
 * 
 * @param string $phone Telefon numarası
 * @return bool Geçerli ise true
 */
function validate_phone_number($phone) {
    if (empty($phone)) {
        return false;
    }
    
    // Sadece rakamları al
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Türkiye telefon formatları:
    // Cep telefonu: 05XXXXXXXXX (11 hane)
    // Sabit hat: 0XXXXXXXXX (10 hane, şehir kodu ile)
    
    if (strlen($phone) === 11 && substr($phone, 0, 2) === '05') {
        // Cep telefonu formatı
        return true;
    } elseif (strlen($phone) === 10 && $phone[0] === '0') {
        // Sabit hat formatı
        return true;
    }
    
    return false;
}

/**
 * Email format doğrulaması
 * 
 * @param string $email Email adresi
 * @return bool Geçerli ise true
 */
function validate_email_format($email) {
    if (empty($email)) {
        return false;
    }
    
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Tarih format doğrulaması ve normalize etme
 * 
 * @param string $date Tarih string'i
 * @param string $output_format Çıktı formatı (varsayılan: Y-m-d)
 * @return array ['valid' => bool, 'date' => string|null, 'original_format' => string|null]
 */
function validate_and_normalize_date($date, $output_format = 'Y-m-d') {
    if (empty($date)) {
        return ['valid' => false, 'date' => null, 'original_format' => null];
    }
    
    // Yaygın Türkçe tarih formatları
    $formats = [
        'd.m.Y',     // 15.03.1985
        'd/m/Y',     // 15/03/1985
        'd-m-Y',     // 15-03-1985
        'Y-m-d',     // 1985-03-15
        'Y/m/d',     // 1985/03/15
        'Y.m.d',     // 1985.03.15
        'd.m.y',     // 15.03.85
        'd/m/y',     // 15/03/85
        'd-m-y',     // 15-03-85
    ];
    
    $date = trim($date);
    
    foreach ($formats as $format) {
        $datetime = DateTime::createFromFormat($format, $date);
        if ($datetime && $datetime->format($format) === $date) {
            return [
                'valid' => true,
                'date' => $datetime->format($output_format),
                'original_format' => $format
            ];
        }
    }
    
    // Excel tarih seri numarası kontrolü (Excel'den gelen sayısal tarihler)
    if (is_numeric($date) && $date > 1) {
        try {
            // Excel'in 1900-01-01'den itibaren gün sayısı formatı
            $excel_base = new DateTime('1899-12-30'); // Excel'in base tarihi
            $excel_base->add(new DateInterval('P' . floor($date) . 'D'));
            
            return [
                'valid' => true,
                'date' => $excel_base->format($output_format),
                'original_format' => 'Excel Serial'
            ];
        } catch (Exception $e) {
            // Excel serial format hatası
        }
    }
    
    return ['valid' => false, 'date' => null, 'original_format' => null];
}

/**
 * Para birimi format doğrulaması ve normalize etme
 * 
 * @param string $amount Para miktarı
 * @return array ['valid' => bool, 'amount' => float|null, 'formatted' => string|null]
 */
function validate_and_normalize_currency($amount) {
    if (empty($amount)) {
        return ['valid' => false, 'amount' => null, 'formatted' => null];
    }
    
    // Para birimi sembollerini temizle
    $cleaned = preg_replace('/[₺\$€£¥TL\s]/', '', $amount);
    
    // Türkçe nokta/virgül formatını normalize et
    $cleaned = str_replace('.', '', $cleaned); // Binlik ayıracı noktayı kaldır
    $cleaned = str_replace(',', '.', $cleaned); // Ondalık virgülü noktaya çevir
    
    if (is_numeric($cleaned)) {
        $numeric_amount = floatval($cleaned);
        return [
            'valid' => true,
            'amount' => $numeric_amount,
            'formatted' => number_format($numeric_amount, 2, ',', '.')
        ];
    }
    
    return ['valid' => false, 'amount' => null, 'formatted' => null];
}

/**
 * Clean and split multi-value fields separated by "/" or other delimiters
 * 
 * @param string $value Value that might contain multiple entries
 * @param string $type Type of data (tc_kimlik, phone, date, name)
 * @return array ['primary' => string, 'secondary' => array, 'all_valid' => bool]
 */
function clean_multi_value_field($value, $type = 'general') {
    if (empty($value)) {
        return ['primary' => '', 'secondary' => [], 'all_valid' => true];
    }
    
    // Split by common delimiters
    $delimiters = ['/', '|', ';', '&'];
    
    // For names, also consider "-" as a delimiter (common in Turkish family names)
    if ($type === 'name') {
        $delimiters[] = '-';
    }
    
    $parts = [$value]; // Default to single value
    
    foreach ($delimiters as $delimiter) {
        if (strpos($value, $delimiter) !== false) {
            $parts = explode($delimiter, $value);
            break;
        }
    }
    
    // Clean and validate each part
    $cleaned_parts = [];
    $valid_parts = [];
    
    foreach ($parts as $part) {
        $part = trim($part);
        if (empty($part)) continue;
        
        $cleaned_parts[] = $part;
        
        // Type-specific validation
        switch ($type) {
            case 'tc_kimlik':
                if (validate_tc_kimlik($part)) {
                    $valid_parts[] = $part;
                }
                break;
            case 'phone':
                // Clean phone number
                $clean_phone = preg_replace('/[^0-9]/', '', $part);
                if (validate_phone_number($clean_phone)) {
                    $valid_parts[] = $clean_phone;
                }
                break;
            case 'date':
                $date_result = validate_and_normalize_date($part);
                if ($date_result['valid']) {
                    $valid_parts[] = $date_result['date'];
                }
                break;
            case 'name':
                // For names, consider all non-empty parts as valid
                if (strlen($part) > 1) {
                    $valid_parts[] = $part;
                }
                break;
            default:
                $valid_parts[] = $part;
                break;
        }
    }
    
    return [
        'primary' => !empty($valid_parts) ? $valid_parts[0] : (!empty($cleaned_parts) ? $cleaned_parts[0] : ''),
        'secondary' => array_slice($valid_parts, 1),
        'all_values' => $cleaned_parts,
        'all_valid' => count($valid_parts) === count($cleaned_parts) && count($cleaned_parts) > 0
    ];
}

/**
 * Extract and clean customer name from complex name fields
 * 
 * @param string $full_name Full name that might contain multiple people
 * @return array ['first_name' => string, 'last_name' => string, 'additional_names' => array]
 */
function extract_customer_name($full_name) {
    if (empty($full_name)) {
        return ['first_name' => '', 'last_name' => '', 'additional_names' => []];
    }
    
    // Clean the name
    $full_name = trim($full_name);
    
    // Handle multiple names separated by "/" or multiple spaces, but NOT hyphen (as hyphens are part of Turkish names)
    $name_result = clean_multi_value_field($full_name, 'name');
    $primary_name = $name_result['primary'];
    $additional_names = $name_result['secondary'];
    
    // Split primary name into first and last
    $name_parts = explode(' ', trim($primary_name));
    $first_name = $name_parts[0] ?? '';
    $last_name = count($name_parts) > 1 ? implode(' ', array_slice($name_parts, 1)) : '';
    
    return [
        'first_name' => $first_name,
        'last_name' => $last_name,
        'additional_names' => $additional_names
    ];
}

/**
 * Clean and validate policy number
 * 
 * @param string $policy_number Raw policy number
 * @return array ['valid' => bool, 'cleaned' => string, 'length_issue' => bool]
 */
function clean_policy_number($policy_number) {
    if (empty($policy_number)) {
        return ['valid' => false, 'cleaned' => '', 'length_issue' => false];
    }
    
    // Remove non-alphanumeric characters except dash and underscore
    $cleaned = preg_replace('/[^A-Za-z0-9\-_]/', '', trim($policy_number));
    
    // Check length (typical policy numbers are 6-20 characters)
    $length_issue = strlen($cleaned) > 50; // Database field limit
    
    return [
        'valid' => !empty($cleaned) && !$length_issue,
        'cleaned' => $cleaned,
        'length_issue' => $length_issue
    ];
}

/**
 * Enhanced data cleaning and validation for import
 * 
 * @param array $row_data Raw row data from CSV
 * @return array ['cleaned_data' => array, 'issues' => array, 'warnings' => array]
 */
function clean_and_validate_import_row($row_data) {
    $cleaned_data = [];
    $issues = [];
    $warnings = [];
    
    foreach ($row_data as $field => $value) {
        if (empty($value)) {
            $cleaned_data[$field] = '';
            continue;
        }
        
        switch ($field) {
            case 'tc_kimlik':
            case 'tc_identity':
                $result = clean_multi_value_field($value, 'tc_kimlik');
                $cleaned_data[$field] = $result['primary'];
                
                // Multiple values are now handled by the enhanced import system
                // Only report warnings for format issues, not multiple values
                if (empty($result['primary']) && !empty($value)) {
                    $issues[] = "TC Kimlik: '{$value}' geçersiz format";
                }
                if (!empty($result['secondary'])) {
                    $cleaned_data[$field . '_additional'] = implode(', ', $result['secondary']);
                }
                break;
                
            case 'phone':
            case 'telefon':
                $result = clean_multi_value_field($value, 'phone');
                $cleaned_data[$field] = $result['primary'];
                
                // Multiple values are now handled by the enhanced import system
                // Only report warnings for format issues, not multiple values
                if (empty($result['primary']) && !empty($value)) {
                    $issues[] = "Telefon: '{$value}' geçersiz format";
                }
                if (!empty($result['secondary'])) {
                    $cleaned_data[$field . '_additional'] = implode(', ', $result['secondary']);
                }
                break;
                
            case 'birth_date':
            case 'dogum_tarihi':
                $result = clean_multi_value_field($value, 'date');
                $cleaned_data[$field] = $result['primary'];
                
                // Multiple values are now handled by the enhanced import system
                // Only report warnings for format issues, not multiple values
                if (empty($result['primary']) && !empty($value)) {
                    $issues[] = "Doğum Tarihi: '{$value}' geçersiz format";
                }
                break;
                
            case 'first_name':
            case 'last_name':
            case 'full_name':
            case 'ad_soyad':
                if (in_array($field, ['full_name', 'ad_soyad'])) {
                    $name_result = extract_customer_name($value);
                    $cleaned_data['first_name'] = $name_result['first_name'];
                    $cleaned_data['last_name'] = $name_result['last_name'];
                    
                    // Multiple names are now handled by the enhanced import system
                    // Store additional names without warning as they'll be processed properly
                    if (!empty($name_result['additional_names'])) {
                        $cleaned_data['additional_names'] = implode(', ', $name_result['additional_names']);
                    }
                } else {
                    $cleaned_data[$field] = sanitize_text_field($value);
                }
                break;
                
            case 'policy_number':
            case 'police_no':
                $result = clean_policy_number($value);
                $cleaned_data[$field] = $result['cleaned'];
                
                if (!$result['valid']) {
                    if ($result['length_issue']) {
                        $issues[] = "Poliçe No: '{$value}' çok uzun (50 karakterden fazla)";
                    } else {
                        $issues[] = "Poliçe No: '{$value}' geçersiz format";
                    }
                }
                break;
                
            case 'premium_amount':
            case 'prim_tutari':
                $currency_result = validate_and_normalize_currency($value);
                if ($currency_result['valid']) {
                    $cleaned_data[$field] = $currency_result['amount'];
                } else {
                    $cleaned_data[$field] = 0;
                    $issues[] = "Prim Tutarı: '{$value}' geçersiz format";
                }
                break;
                
            case 'start_date':
            case 'end_date':
            case 'baslangic_tarihi':
            case 'bitis_tarihi':
                $date_result = validate_and_normalize_date($value);
                if ($date_result['valid']) {
                    $cleaned_data[$field] = $date_result['date'];
                } else {
                    $cleaned_data[$field] = null;
                    $issues[] = "Tarih: '{$value}' geçersiz format";
                }
                break;
                
            case 'email':
                if (validate_email_format($value)) {
                    $cleaned_data[$field] = sanitize_email($value);
                } else {
                    $cleaned_data[$field] = '';
                    if (!empty($value)) {
                        $issues[] = "Email: '{$value}' geçersiz format";
                    }
                }
                break;
                
            default:
                $cleaned_data[$field] = sanitize_text_field($value);
                break;
        }
    }
    
    return [
        'cleaned_data' => $cleaned_data,
        'issues' => $issues,
        'warnings' => $warnings
    ];
}

/**
 * Toplu veri doğrulama fonksiyonu
 * 
 * @param array $data Doğrulanacak veri
 * @param array $rules Doğrulama kuralları
 * @return array ['valid' => bool, 'errors' => array, 'validated_data' => array]
 */
function validate_import_data($data, $rules = []) {
    $errors = [];
    $validated_data = $data;
    
    foreach ($rules as $field => $rule_set) {
        if (!isset($data[$field])) {
            continue;
        }
        
        $value = $data[$field];
        
        foreach ($rule_set as $rule) {
            switch ($rule) {
                case 'tc_kimlik':
                    if (!empty($value) && !validate_tc_kimlik($value)) {
                        $errors[$field][] = 'Geçersiz TC Kimlik numarası';
                    }
                    break;
                    
                case 'phone':
                    if (!empty($value) && !validate_phone_number($value)) {
                        $errors[$field][] = 'Geçersiz telefon numarası formatı';
                    }
                    break;
                    
                case 'email':
                    if (!empty($value) && !validate_email_format($value)) {
                        $errors[$field][] = 'Geçersiz email formatı';
                    }
                    break;
                    
                case 'date':
                    if (!empty($value)) {
                        $date_result = validate_and_normalize_date($value);
                        if (!$date_result['valid']) {
                            $errors[$field][] = 'Geçersiz tarih formatı';
                        } else {
                            $validated_data[$field] = $date_result['date'];
                        }
                    }
                    break;
                    
                case 'currency':
                    if (!empty($value)) {
                        $currency_result = validate_and_normalize_currency($value);
                        if (!$currency_result['valid']) {
                            $errors[$field][] = 'Geçersiz para miktarı formatı';
                        } else {
                            $validated_data[$field] = $currency_result['amount'];
                        }
                    }
                    break;
                    
                case 'required':
                    if (empty($value)) {
                        $errors[$field][] = 'Bu alan zorunludur';
                    }
                    break;
            }
        }
    }
    
    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'validated_data' => $validated_data
    ];
}