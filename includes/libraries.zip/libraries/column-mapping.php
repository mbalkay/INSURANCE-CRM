<?php
/**
 * Column Auto-Detection and Template System for Import
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Otomatik sütun tanıma fonksiyonu
 * 
 * @param array $headers Dosyadaki başlık satırı
 * @return array Otomatik eşleştirilen sütunlar
 */
function auto_detect_columns($headers) {
    $detected_mappings = [];
    
    // Türkçe başlık eşleştirme tablosu
    $header_patterns = [
        'ad' => [
            'ad', 'isim', 'name', 'first_name', 'adi', 'müşteri_adı', 'customer_name',
            'müşteri adı', 'ad soyad', 'ad-soyad', 'adsoyad'
        ],
        'soyad' => [
            'soyad', 'surname', 'last_name', 'soyadı', 'family_name'
        ],
        'tc_kimlik' => [
            'tc', 'tc_kimlik', 'tc_no', 'tc kimlik', 'tc kimlik no', 'tcno', 
            'tckimlik', 'tc_kimlik_no', 'kimlik_no', 'kimlik no', 'identity_number'
        ],
        'telefon' => [
            'telefon', 'tel', 'phone', 'mobile', 'gsm', 'cep', 'cep_tel', 
            'telefon_no', 'telefon no', 'phone_number', 'cell_phone'
        ],
        'adres' => [
            'adres', 'address', 'ev_adresi', 'ev adresi', 'ikamet_adresi', 
            'ikamet adresi', 'full_address'
        ],
        'dogum_tarih' => [
            'dogum_tarihi', 'doğum tarihi', 'dogum', 'doğum', 'birth_date', 
            'date_of_birth', 'dogum_tarih', 'birthdate', 'dt'
        ],
        'police_no' => [
            'police_no', 'poliçe_no', 'poliçe no', 'police', 'poliçe', 
            'policy_number', 'policy_no', 'policy', 'policeno'
        ],
        'police_turu' => [
            'police_turu', 'poliçe_türü', 'poliçe türü', 'police_type', 
            'policy_type', 'insurance_type', 'sigorta_türü', 'sigorta türü'
        ],
        'sigorta_sirketi' => [
            'sigorta_sirketi', 'sigorta şirketi', 'şirket', 'company', 
            'insurance_company', 'insurer', 'carrier'
        ],
        'baslangic_tarih' => [
            'baslangic_tarihi', 'başlangıç tarihi', 'başlangıç_tarihi', 'baslangic_tarih', 'başlangıç tarih',
            'start_date', 'policy_start', 'effective_date', 'baslangic', 'tarih', 'başlangıç'
        ],
        'bitis_tarih' => [
            'bitis_tarihi', 'bitiş tarihi', 'bitiş_tarihi', 'bitis_tarih', 'bitiş tarih',
            'end_date', 'expiry_date', 'policy_end', 'bitis', 'bitiş'
        ],
        'prim_tutari' => [
            'prim', 'prim_tutari', 'prim tutarı', 'premium', 'premium_amount', 
            'tutar', 'amount', 'price', 'cost'
        ],
        'sigorta_ettiren' => [
            'sigorta_ettiren', 'sigorta ettiren', 'policyholder', 'insured', 
            'müşteri', 'customer'
        ],
        'musteri_temsilcisi' => [
            'musteri_temsilcisi', 'müşteri temsilcisi', 'temsilci', 'agent', 
            'representative', 'sales_rep', 'advisor'
        ],
        'ilk_kayit_eden' => [
            'ilk_kayit_eden', 'ilk kayıt eden', 'kayit_eden', 'kayıt eden', 
            'created_by', 'entered_by'
        ],
        'network' => [
            'network', 'kanal', 'channel', 'source', 'kaynak'
        ],
        'odeme_tipi' => [
            'odeme_tipi', 'ödeme tipi', 'ödeme_türü', 'payment_type', 
            'payment_method', 'odeme'
        ],
        'email' => [
            'email', 'e-mail', 'e_mail', 'eposta', 'e-posta', 'e_posta', 
            'electronic_mail', 'mail'
        ],
        'full_name' => [
            'ad_soyad', 'ad soyad', 'adsoyad', 'ad-soyad', 'full_name', 'name',
            'isim_soyisim', 'isim soyisim', 'customer_name', 'müşteri_adı', 'müşteri adı'
        ]
    ];
    
    // Her başlık için en iyi eşleşmeyi bul
    foreach ($headers as $index => $header) {
        $header_clean = strtolower(trim($header));
        $header_clean = str_replace([' ', '-', '_'], '', $header_clean);
        
        // Türkçe karakterleri normalize et
        $header_normalized = str_replace(
            ['ı', 'ğ', 'ü', 'ş', 'ö', 'ç', 'İ', 'Ğ', 'Ü', 'Ş', 'Ö', 'Ç'],
            ['i', 'g', 'u', 's', 'o', 'c', 'i', 'g', 'u', 's', 'o', 'c'],
            $header_clean
        );
        
        foreach ($header_patterns as $field => $patterns) {
            foreach ($patterns as $pattern) {
                $pattern_clean = strtolower(str_replace([' ', '-', '_'], '', $pattern));
                $pattern_normalized = str_replace(
                    ['ı', 'ğ', 'ü', 'ş', 'ö', 'ç', 'İ', 'Ğ', 'Ü', 'Ş', 'Ö', 'Ç'],
                    ['i', 'g', 'u', 's', 'o', 'c', 'i', 'g', 'u', 's', 'o', 'c'],
                    $pattern_clean
                );
                
                // Tam eşleşme
                if ($header_normalized === $pattern_normalized) {
                    $detected_mappings[$field] = $index;
                    break 2;
                }
                
                // Kısmi eşleşme (içeriyor)
                if (strpos($header_normalized, $pattern_normalized) !== false) {
                    if (!isset($detected_mappings[$field])) {
                        $detected_mappings[$field] = $index;
                    }
                }
            }
        }
    }
    
    return $detected_mappings;
}

/**
 * Sütun eşleştirme template'ini veritabanına kaydeder
 * 
 * @param string $template_name Template adı
 * @param array $column_mapping Sütun eşleştirme verisi
 * @param int $user_id Kullanıcı ID
 * @return bool Başarılı ise true
 */
function save_column_mapping_template($template_name, $column_mapping, $user_id) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'insurance_crm_import_templates';
    
    // Tablo yoksa oluştur
    create_import_template_table();
    
    $template_data = [
        'name' => sanitize_text_field($template_name),
        'mapping_data' => wp_json_encode($column_mapping),
        'user_id' => (int)$user_id,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql')
    ];
    
    // Aynı isimde template varsa güncelle
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table_name WHERE name = %s AND user_id = %d",
        $template_name,
        $user_id
    ));
    
    if ($existing) {
        $result = $wpdb->update(
            $table_name,
            [
                'mapping_data' => $template_data['mapping_data'],
                'updated_at' => $template_data['updated_at']
            ],
            ['id' => $existing],
            ['%s', '%s'],
            ['%d']
        );
    } else {
        $result = $wpdb->insert($table_name, $template_data);
    }
    
    return $result !== false;
}

/**
 * Kullanıcının kayıtlı template'lerini getirir
 * 
 * @param int $user_id Kullanıcı ID
 * @return array Template listesi
 */
function get_user_column_templates($user_id) {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'insurance_crm_import_templates';
    
    // Tablo yoksa boş dizi döndür
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        return [];
    }
    
    $templates = $wpdb->get_results($wpdb->prepare(
        "SELECT id, name, mapping_data, created_at, updated_at 
         FROM $table_name 
         WHERE user_id = %d 
         ORDER BY updated_at DESC",
        $user_id
    ), ARRAY_A);
    
    // JSON verilerini decode et
    foreach ($templates as &$template) {
        $template['mapping_data'] = json_decode($template['mapping_data'], true);
    }
    
    return $templates;
}

/**
 * Template tablosunu oluşturur
 */
function create_import_template_table() {
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'insurance_crm_import_templates';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        mapping_data longtext NOT NULL,
        user_id int(11) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY name (name)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

/**
 * Sütun eşleştirme önerilerini getirir
 * 
 * @param array $headers Dosya başlıkları
 * @param int $user_id Kullanıcı ID
 * @return array Öneriler
 */
function get_column_mapping_suggestions($headers, $user_id) {
    $suggestions = [];
    
    // 1. Otomatik algılama
    $auto_detected = auto_detect_columns($headers);
    if (!empty($auto_detected)) {
        $suggestions['auto_detected'] = [
            'name' => 'Otomatik Algılama',
            'type' => 'auto',
            'mapping' => $auto_detected,
            'confidence' => calculate_mapping_confidence($auto_detected, $headers)
        ];
    }
    
    // 2. Kullanıcının kayıtlı template'leri
    $user_templates = get_user_column_templates($user_id);
    foreach ($user_templates as $template) {
        if (is_compatible_template($template['mapping_data'], $headers)) {
            $suggestions['template_' . $template['id']] = [
                'name' => $template['name'],
                'type' => 'template',
                'mapping' => $template['mapping_data'],
                'confidence' => calculate_template_compatibility($template['mapping_data'], $headers),
                'created_at' => $template['created_at']
            ];
        }
    }
    
    return $suggestions;
}

/**
 * Eşleştirme güvenilirlik skorunu hesaplar
 * 
 * @param array $mapping Eşleştirme verisi
 * @param array $headers Başlık satırı
 * @return int 0-100 arası skor
 */
function calculate_mapping_confidence($mapping, $headers) {
    $total_possible = count(['police_no', 'ad', 'soyad', 'tc_kimlik', 'telefon']);
    $mapped_critical = 0;
    
    $critical_fields = ['police_no', 'ad', 'soyad'];
    foreach ($critical_fields as $field) {
        if (isset($mapping[$field]) && isset($headers[$mapping[$field]])) {
            $mapped_critical++;
        }
    }
    
    return intval(($mapped_critical / count($critical_fields)) * 100);
}

/**
 * Template uyumluluğunu kontrol eder
 * 
 * @param array $template_mapping Template eşleştirmesi
 * @param array $headers Dosya başlıkları
 * @return bool Uyumlu ise true
 */
function is_compatible_template($template_mapping, $headers) {
    $compatible_count = 0;
    $total_mappings = count($template_mapping);
    
    if ($total_mappings === 0) {
        return false;
    }
    
    foreach ($template_mapping as $field => $column_index) {
        if (isset($headers[$column_index])) {
            $compatible_count++;
        }
    }
    
    // En az %60 uyumlu olmalı
    return ($compatible_count / $total_mappings) >= 0.6;
}

/**
 * Template uyumluluk skorunu hesaplar
 * 
 * @param array $template_mapping Template eşleştirmesi
 * @param array $headers Dosya başlıkları
 * @return int 0-100 arası skor
 */
function calculate_template_compatibility($template_mapping, $headers) {
    $compatible_count = 0;
    $total_mappings = count($template_mapping);
    
    if ($total_mappings === 0) {
        return 0;
    }
    
    foreach ($template_mapping as $field => $column_index) {
        if (isset($headers[$column_index])) {
            $compatible_count++;
        }
    }
    
    return intval(($compatible_count / $total_mappings) * 100);
}