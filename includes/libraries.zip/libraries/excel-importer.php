<?php
/**
 * Excel İçe Aktarım için Yardımcı Sınıf
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Excel dosyasını okur ve CSV format gibi döndürür
 * 
 * @param string $file_path Dosya yolu
 * @param int $worksheet_index Hangi sheet'i okuyacak (varsayılan: 0)
 * @return array CSV formatına benzer dizi
 * @throws Exception Hata durumunda
 */
function read_excel_file($file_path, $worksheet_index = 0) {
    // Vendor directory path - çoklu yol denemesi
    $vendor_paths = [
        defined('INSURANCE_CRM_VENDOR_DIR') ? INSURANCE_CRM_VENDOR_DIR : null,
        dirname(dirname(dirname(__FILE__))) . '/vendor/',
        plugin_dir_path(__FILE__) . '../../../vendor/',
        __DIR__ . '/../../vendor/'
    ];
    
    $vendor_dir = null;
    foreach ($vendor_paths as $path) {
        if ($path && file_exists($path . 'phpoffice/phpspreadsheet/src/Spreadsheet.php')) {
            $vendor_dir = $path;
            break;
        }
    }
    
    // PhpSpreadsheet var mı kontrol et
    if (!$vendor_dir) {
        throw new Exception('PhpSpreadsheet kütüphanesi bulunamadı. Lütfen sadece CSV dosyası kullanın.');
    }

    require_once $vendor_dir . 'autoload.php';

    try {
        // Excel dosyasını yükle
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(true);
        $spreadsheet = $reader->load($file_path);
        
        // Belirtilen worksheet'i al
        $worksheets = $spreadsheet->getAllSheets();
        if (!isset($worksheets[$worksheet_index])) {
            throw new Exception('Belirtilen sayfa (sheet) Excel dosyasında bulunamadı.');
        }
        
        $worksheet = $worksheets[$worksheet_index];
        $data = $worksheet->toArray();
        
        // Boş satırları temizle
        $data = array_filter($data, function($row) {
            return !empty(array_filter($row, function($cell) {
                return !empty(trim($cell));
            }));
        });
        
        // İndeksleri sıfırla
        $data = array_values($data);
        
        if (empty($data)) {
            throw new Exception('Excel dosyası boş veya hiç veri içermiyor.');
        }
        
        return $data;
        
    } catch (Exception $e) {
        throw new Exception('Excel dosyası okunurken hata oluştu: ' . $e->getMessage());
    }
}

/**
 * Excel dosyasından başlıkları ve örnek verileri okur (CSV okuma fonksiyonuna benzer)
 * 
 * @param string $file_path Excel dosya yolu
 * @return array CSV read_csv_headers fonksiyonuna benzer format
 * @throws Exception Hata durumunda
 */
function read_excel_headers($file_path) {
    try {
        $data = read_excel_file($file_path, 0);
        
        if (empty($data)) {
            throw new Exception('Excel dosyasında veri bulunamadı.');
        }
        
        $headers = array_shift($data); // İlk satırı başlik olarak al
        
        // Başlıkları temizle ve UTF-8'e çevir
        $headers = array_map(function($header) {
            if (is_string($header)) {
                $header = trim($header);
                if (!mb_check_encoding($header, 'UTF-8')) {
                    $header = mb_convert_encoding($header, 'UTF-8', ['UTF-8', 'ISO-8859-9', 'Windows-1254', 'ASCII']);
                }
            }
            return empty($header) ? 'Boş_Sütun' : $header;
        }, $headers);
        
        // Örnek verileri hazırla (en fazla 5 satır)
        $sample_data = array_slice($data, 0, 5);
        
        // Örnek verileri de temizle
        $sample_data = array_map(function($row) use ($headers) {
            $row = array_pad($row, count($headers), '');
            return array_map(function($cell) {
                if (is_string($cell) && !mb_check_encoding($cell, 'UTF-8')) {
                    $cell = mb_convert_encoding($cell, 'UTF-8', ['UTF-8', 'ISO-8859-9', 'Windows-1254', 'ASCII']);
                }
                return $cell;
            }, $row);
        }, $sample_data);
        
        return [
            'headers' => $headers,
            'sample_data' => $sample_data,
            'delimiter' => null, // Excel için delimiter yok
            'total_columns' => count($headers),
            'sample_rows' => count($sample_data)
        ];
        
    } catch (Exception $e) {
        throw new Exception('Excel başlıkları okunurken hata: ' . $e->getMessage());
    }
}

/**
 * Excel dosyasından tam veri okur (CSV okuma fonksiyonuna benzer)
 * 
 * @param string $file_path Excel dosya yolu
 * @return array CSV read_csv_full_data fonksiyonuna benzer format
 * @throws Exception Hata durumunda
 */
function read_excel_full_data($file_path) {
    try {
        $data = read_excel_file($file_path, 0);
        
        if (empty($data)) {
            throw new Exception('Excel dosyasında veri bulunamadı.');
        }
        
        $headers = array_shift($data); // İlk satırı başlik olarak al
        
        // Başlıkları temizle ve UTF-8'e çevir
        $headers = array_map(function($header) {
            if (is_string($header)) {
                $header = trim($header);
                if (!mb_check_encoding($header, 'UTF-8')) {
                    $header = mb_convert_encoding($header, 'UTF-8', ['UTF-8', 'ISO-8859-9', 'Windows-1254', 'ASCII']);
                }
            }
            return empty($header) ? 'Boş_Sütun' : $header;
        }, $headers);
        
        // Tüm verileri temizle
        $data = array_map(function($row) use ($headers) {
            $row = array_pad($row, count($headers), '');
            return array_map(function($cell) {
                if (is_string($cell) && !mb_check_encoding($cell, 'UTF-8')) {
                    $cell = mb_convert_encoding($cell, 'UTF-8', ['UTF-8', 'ISO-8859-9', 'Windows-1254', 'ASCII']);
                }
                return $cell;
            }, $row);
        }, $data);
        
        // Örnek veri de hazırla
        $sample_data = array_slice($data, 0, 5);
        
        return [
            'headers' => $headers,
            'data' => $data,
            'sample_data' => $sample_data,
            'delimiter' => null, // Excel için delimiter yok
            'total_columns' => count($headers),
            'total_rows' => count($data),
            'sample_rows' => count($sample_data)
        ];
        
    } catch (Exception $e) {
        throw new Exception('Excel verileri okunurken hata: ' . $e->getMessage());
    }
}

/**
 * Excel dosyasının tüm sayfalarını listeler
 * 
 * @param string $file_path Excel dosya yolu
 * @return array Sayfa isimleri
 * @throws Exception Hata durumunda
 */
function get_excel_worksheets($file_path) {
    // Vendor directory path - çoklu yol denemesi
    $vendor_paths = [
        defined('INSURANCE_CRM_VENDOR_DIR') ? INSURANCE_CRM_VENDOR_DIR : null,
        dirname(dirname(dirname(__FILE__))) . '/vendor/',
        plugin_dir_path(__FILE__) . '../../../vendor/',
        __DIR__ . '/../../vendor/'
    ];
    
    $vendor_dir = null;
    foreach ($vendor_paths as $path) {
        if ($path && file_exists($path . 'phpoffice/phpspreadsheet/src/Spreadsheet.php')) {
            $vendor_dir = $path;
            break;
        }
    }
    
    if (!$vendor_dir) {
        throw new Exception('PhpSpreadsheet kütüphanesi bulunamadı.');
    }

    require_once $vendor_dir . 'autoload.php';

    try {
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader('Xlsx');
        $reader->setReadDataOnly(true);
        $spreadsheet = $reader->load($file_path);
        
        $worksheets = $spreadsheet->getAllSheets();
        $sheet_names = [];
        
        foreach ($worksheets as $index => $worksheet) {
            $sheet_names[$index] = $worksheet->getTitle();
        }
        
        return $sheet_names;
        
    } catch (Exception $e) {
        throw new Exception('Excel sayfaları listelenirken hata: ' . $e->getMessage());
    }
}

/**
 * Dosyanın Excel olup olmadığını kontrol eder
 * 
 * @param string $file_path Dosya yolu
 * @return bool Excel dosyası ise true
 */
function is_excel_file($file_path) {
    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    return in_array($extension, ['xlsx', 'xls']);
}

/**
 * Excel dosyasını işler ve mevcut CSV işleme sistemine entegre eder
 * 
 * @param string $file_path Excel dosya yolu
 * @param array $column_mapping Sütun eşleştirme bilgileri
 * @param int $current_user_rep_id Mevcut kullanıcı temsilci ID
 * @param object $wpdb WordPress veritabanı nesnesi
 * @param int $worksheet_index Hangi sayfa işlenecek
 * @return array İşlem sonucu
 */
function process_excel_file_with_mapping($file_path, $column_mapping, $current_user_rep_id, $wpdb, $worksheet_index = 0) {
    try {
        // Excel'i CSV formatına çevir
        $excel_data = read_excel_file($file_path, $worksheet_index);
        
        // Geçici CSV dosyası oluştur
        $temp_csv = tempnam(sys_get_temp_dir(), 'excel_import_') . '.csv';
        $csv_handle = fopen($temp_csv, 'w');
        
        if (!$csv_handle) {
            throw new Exception('Geçici CSV dosyası oluşturulamadı.');
        }
        
        // Excel verilerini CSV formatında yaz
        foreach ($excel_data as $row) {
            fputcsv($csv_handle, $row, ';'); // Türkçe için nokталı virgül
        }
        fclose($csv_handle);
        
        // Mevcut CSV işleme fonksiyonunu kullan
        if (!function_exists('process_csv_file_with_mapping')) {
            require_once dirname(dirname(__DIR__)) . '/templates/representative-panel/import/csv-importer.php';
        }
        
        // CSV işleme fonksiyonunu çağır
        $result = process_csv_file_with_mapping($temp_csv, $column_mapping, $current_user_rep_id, $wpdb);
        
        // Geçici dosyayı sil
        unlink($temp_csv);
        
        return $result;
        
    } catch (Exception $e) {
        // Geçici dosya varsa sil
        if (isset($temp_csv) && file_exists($temp_csv)) {
            unlink($temp_csv);
        }
        throw $e;
    }
}