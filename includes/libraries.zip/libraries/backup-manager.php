<?php
/**
 * Backup and Rollback System for Import Operations
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Import backup ve rollback yönetimi
 */
class ImportBackupManager {
    
    private $wpdb;
    private $backup_table;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->backup_table = $wpdb->prefix . 'insurance_crm_import_backups';
        $this->create_backup_table();
    }
    
    /**
     * Backup tablosunu oluşturur
     */
    private function create_backup_table() {
        $charset_collate = $this->wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->backup_table} (
            id int(11) NOT NULL AUTO_INCREMENT,
            backup_name varchar(255) NOT NULL,
            backup_type enum('import_customers', 'import_policies', 'full_import') DEFAULT 'full_import',
            backup_data longtext NOT NULL,
            affected_tables text NOT NULL,
            record_count int(11) DEFAULT 0,
            file_path varchar(500) DEFAULT NULL,
            created_by int(11) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            restored_at datetime DEFAULT NULL,
            is_restored tinyint(1) DEFAULT 0,
            PRIMARY KEY (id),
            KEY created_by (created_by),
            KEY created_at (created_at),
            KEY backup_type (backup_type)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Import öncesi backup oluşturur
     */
    public function create_pre_import_backup($import_data, $user_id, $backup_name = null) {
        if (!$backup_name) {
            $backup_name = 'Pre-import backup ' . date('Y-m-d H:i:s');
        }
        
        // Etkilenecek müşterilerin ve poliçelerin backup'ını al
        $affected_customers = [];
        $affected_policies = [];
        
        // Müşterileri kontrol et
        if (isset($import_data['customers'])) {
            foreach ($import_data['customers'] as $customer_data) {
                if (isset($customer_data['customer_id']) && $customer_data['customer_id']) {
                    $existing_customer = $this->wpdb->get_row($this->wpdb->prepare(
                        "SELECT * FROM {$this->wpdb->prefix}insurance_crm_customers WHERE id = %d",
                        $customer_data['customer_id']
                    ), ARRAY_A);
                    
                    if ($existing_customer) {
                        $affected_customers[] = $existing_customer;
                    }
                }
            }
        }
        
        // Poliçeleri kontrol et
        if (isset($import_data['policies'])) {
            foreach ($import_data['policies'] as $policy_data) {
                $existing_policy = $this->wpdb->get_row($this->wpdb->prepare(
                    "SELECT * FROM {$this->wpdb->prefix}insurance_crm_policies WHERE policy_number = %s",
                    $policy_data['policy_number']
                ), ARRAY_A);
                
                if ($existing_policy) {
                    $affected_policies[] = $existing_policy;
                }
            }
        }
        
        $backup_data = [
            'customers' => $affected_customers,
            'policies' => $affected_policies,
            'import_summary' => [
                'total_customers' => count($import_data['customers'] ?? []),
                'total_policies' => count($import_data['policies'] ?? []),
                'new_customers' => count(array_filter($import_data['customers'] ?? [], function($c) {
                    return !isset($c['customer_id']) || !$c['customer_id'];
                })),
                'existing_customers' => count($affected_customers),
                'existing_policies' => count($affected_policies)
            ]
        ];
        
        $result = $this->wpdb->insert(
            $this->backup_table,
            [
                'backup_name' => $backup_name,
                'backup_type' => 'full_import',
                'backup_data' => wp_json_encode($backup_data),
                'affected_tables' => 'insurance_crm_customers,insurance_crm_policies',
                'record_count' => count($affected_customers) + count($affected_policies),
                'created_by' => $user_id,
                'created_at' => current_time('mysql')
            ]
        );
        
        if ($result === false) {
            throw new Exception('Backup oluşturulamadı: ' . $this->wpdb->last_error);
        }
        
        return $this->wpdb->insert_id;
    }
    
    /**
     * Backup'ı geri yükler
     */
    public function restore_backup($backup_id, $user_id) {
        $backup = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->backup_table} WHERE id = %d AND created_by = %d",
            $backup_id,
            $user_id
        ), ARRAY_A);
        
        if (!$backup) {
            throw new Exception('Backup bulunamadı veya yetkiniz yok.');
        }
        
        if ($backup['is_restored']) {
            throw new Exception('Bu backup zaten geri yüklenmiş.');
        }
        
        $backup_data = json_decode($backup['backup_data'], true);
        
        if (!$backup_data) {
            throw new Exception('Backup verisi okunamadı.');
        }
        
        // Transaction başlat
        $this->wpdb->query('START TRANSACTION');
        
        try {
            // Müşterileri geri yükle
            if (isset($backup_data['customers'])) {
                foreach ($backup_data['customers'] as $customer) {
                    $customer_id = $customer['id'];
                    unset($customer['id']); // ID'yi unset et, güncelleme için
                    
                    $this->wpdb->update(
                        $this->wpdb->prefix . 'insurance_crm_customers',
                        $customer,
                        ['id' => $customer_id]
                    );
                }
            }
            
            // Poliçeleri geri yükle
            if (isset($backup_data['policies'])) {
                foreach ($backup_data['policies'] as $policy) {
                    $policy_id = $policy['id'];
                    unset($policy['id']);
                    
                    $this->wpdb->update(
                        $this->wpdb->prefix . 'insurance_crm_policies',
                        $policy,
                        ['id' => $policy_id]
                    );
                }
            }
            
            // Backup'ı restore edildi olarak işaretle
            $this->wpdb->update(
                $this->backup_table,
                [
                    'is_restored' => 1,
                    'restored_at' => current_time('mysql')
                ],
                ['id' => $backup_id]
            );
            
            $this->wpdb->query('COMMIT');
            
            return [
                'success' => true,
                'message' => 'Backup başarıyla geri yüklendi.',
                'restored_customers' => count($backup_data['customers'] ?? []),
                'restored_policies' => count($backup_data['policies'] ?? [])
            ];
            
        } catch (Exception $e) {
            $this->wpdb->query('ROLLBACK');
            throw new Exception('Backup geri yükleme hatası: ' . $e->getMessage());
        }
    }
    
    /**
     * Kullanıcının backup'larını listeler
     */
    public function get_user_backups($user_id, $limit = 20) {
        $backups = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT id, backup_name, backup_type, record_count, created_at, restored_at, is_restored 
             FROM {$this->backup_table} 
             WHERE created_by = %d 
             ORDER BY created_at DESC 
             LIMIT %d",
            $user_id,
            $limit
        ), ARRAY_A);
        
        return $backups;
    }
    
    /**
     * Eski backup'ları temizler
     */
    public function cleanup_old_backups($days = 30) {
        $deleted = $this->wpdb->query($this->wpdb->prepare(
            "DELETE FROM {$this->backup_table} 
             WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
        
        return $deleted;
    }
    
    /**
     * Backup detaylarını getirir
     */
    public function get_backup_details($backup_id, $user_id) {
        $backup = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->backup_table} WHERE id = %d AND created_by = %d",
            $backup_id,
            $user_id
        ), ARRAY_A);
        
        if (!$backup) {
            return null;
        }
        
        $backup['backup_data'] = json_decode($backup['backup_data'], true);
        return $backup;
    }
}

/**
 * Import versiyonlama sistemi
 */
class ImportVersionManager {
    
    private $wpdb;
    private $version_table;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->version_table = $wpdb->prefix . 'insurance_crm_import_versions';
        $this->create_version_table();
    }
    
    /**
     * Version tablosunu oluşturur
     */
    private function create_version_table() {
        $charset_collate = $this->wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->version_table} (
            id int(11) NOT NULL AUTO_INCREMENT,
            import_session varchar(100) NOT NULL,
            version_number int(11) DEFAULT 1,
            import_type varchar(50) DEFAULT 'csv',
            file_name varchar(255) DEFAULT NULL,
            total_records int(11) DEFAULT 0,
            successful_records int(11) DEFAULT 0,
            failed_records int(11) DEFAULT 0,
            import_summary longtext DEFAULT NULL,
            backup_id int(11) DEFAULT NULL,
            created_by int(11) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_session_version (import_session, version_number),
            KEY created_by (created_by),
            KEY import_session (import_session)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Yeni import versiyonu oluşturur
     */
    public function create_version($session_id, $import_data, $backup_id = null) {
        // Aynı session için son versiyon numarasını al
        $last_version = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT MAX(version_number) FROM {$this->version_table} WHERE import_session = %s",
            $session_id
        ));
        
        $version_number = ($last_version ?? 0) + 1;
        
        $summary = [
            'total_customers' => count($import_data['customers'] ?? []),
            'total_policies' => count($import_data['policies'] ?? []),
            'processed_at' => current_time('mysql'),
            'column_mapping' => $import_data['column_mapping'] ?? []
        ];
        
        $result = $this->wpdb->insert(
            $this->version_table,
            [
                'import_session' => $session_id,
                'version_number' => $version_number,
                'import_type' => 'csv',
                'total_records' => count($import_data['customers'] ?? []) + count($import_data['policies'] ?? []),
                'import_summary' => wp_json_encode($summary),
                'backup_id' => $backup_id,
                'created_by' => get_current_user_id(),
                'created_at' => current_time('mysql')
            ]
        );
        
        if ($result === false) {
            throw new Exception('Version kaydedilemedi: ' . $this->wpdb->last_error);
        }
        
        return [
            'version_id' => $this->wpdb->insert_id,
            'version_number' => $version_number,
            'session_id' => $session_id
        ];
    }
    
    /**
     * Session'ın tüm versiyonlarını getirir
     */
    public function get_session_versions($session_id) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->version_table} WHERE import_session = %s ORDER BY version_number DESC",
            $session_id
        ), ARRAY_A);
    }
}