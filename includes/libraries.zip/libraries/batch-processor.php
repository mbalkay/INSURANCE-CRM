<?php
/**
 * Batch Processing and Progress Tracking for Import System
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Batch processing için session management
 */
class ImportBatchProcessor {
    
    private $session_id;
    private $batch_size;
    private $total_records;
    private $processed_records;
    
    public function __construct($session_id = null, $batch_size = 50) {
        $this->session_id = $session_id ?: uniqid('import_');
        $this->batch_size = $batch_size;
        $this->processed_records = 0;
        
        // Session verilerini başlat
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    /**
     * Import işlemini başlatır
     */
    public function start_import($total_records, $data) {
        $this->total_records = $total_records;
        
        // Session'a kaydet
        $_SESSION['import_' . $this->session_id] = [
            'total_records' => $total_records,
            'processed_records' => 0,
            'start_time' => time(),
            'status' => 'processing',
            'data' => $data,
            'errors' => [],
            'current_batch' => 0
        ];
        
        return $this->session_id;
    }
    
    /**
     * Bir batch işler
     */
    public function process_batch($batch_number, $processor_callback) {
        $session_key = 'import_' . $this->session_id;
        
        if (!isset($_SESSION[$session_key])) {
            throw new Exception('Import session bulunamadı.');
        }
        
        $session_data = $_SESSION[$session_key];
        $start_index = $batch_number * $this->batch_size;
        $end_index = min($start_index + $this->batch_size, $session_data['total_records']);
        
        $batch_data = array_slice($session_data['data'], $start_index, $this->batch_size);
        
        try {
            $result = call_user_func($processor_callback, $batch_data, $batch_number);
            
            // İlerlemeyi güncelle
            $processed = min($end_index, $session_data['total_records']);
            $_SESSION[$session_key]['processed_records'] = $processed;
            $_SESSION[$session_key]['current_batch'] = $batch_number;
            
            // Son batch ise tamamlandı olarak işaretle
            if ($processed >= $session_data['total_records']) {
                $_SESSION[$session_key]['status'] = 'completed';
                $_SESSION[$session_key]['end_time'] = time();
            }
            
            return [
                'success' => true,
                'processed' => $processed,
                'total' => $session_data['total_records'],
                'progress' => round(($processed / $session_data['total_records']) * 100, 2),
                'batch_result' => $result
            ];
            
        } catch (Exception $e) {
            $_SESSION[$session_key]['errors'][] = [
                'batch' => $batch_number,
                'error' => $e->getMessage(),
                'time' => time()
            ];
            
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'processed' => $_SESSION[$session_key]['processed_records'],
                'total' => $session_data['total_records']
            ];
        }
    }
    
    /**
     * Import durumunu getirir
     */
    public function get_status() {
        $session_key = 'import_' . $this->session_id;
        
        if (!isset($_SESSION[$session_key])) {
            return ['status' => 'not_found'];
        }
        
        $data = $_SESSION[$session_key];
        $progress = $data['total_records'] > 0 ? 
            round(($data['processed_records'] / $data['total_records']) * 100, 2) : 0;
        
        return [
            'status' => $data['status'],
            'progress' => $progress,
            'processed' => $data['processed_records'],
            'total' => $data['total_records'],
            'errors' => $data['errors'] ?? [],
            'elapsed_time' => isset($data['start_time']) ? time() - $data['start_time'] : 0
        ];
    }
    
    /**
     * Session'ı temizler
     */
    public function cleanup() {
        $session_key = 'import_' . $this->session_id;
        if (isset($_SESSION[$session_key])) {
            unset($_SESSION[$session_key]);
        }
    }
    
    /**
     * Memory optimizasyonu için büyük dosyaları chunk halinde okur
     */
    public static function read_file_in_chunks($file_path, $chunk_callback, $chunk_size = 1000) {
        if (!file_exists($file_path)) {
            throw new Exception('Dosya bulunamadı: ' . $file_path);
        }
        
        $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
        
        if ($extension === 'xlsx') {
            return self::read_excel_in_chunks($file_path, $chunk_callback, $chunk_size);
        } else {
            return self::read_csv_in_chunks($file_path, $chunk_callback, $chunk_size);
        }
    }
    
    /**
     * CSV dosyasını chunk halinde okur
     */
    private static function read_csv_in_chunks($file_path, $chunk_callback, $chunk_size) {
        $file = fopen($file_path, 'r');
        if (!$file) {
            throw new Exception('CSV dosyası açılamadı');
        }
        
        // BOM kontrolü
        $bom = fread($file, 3);
        if ($bom !== "\xEF\xBB\xBF") {
            rewind($file);
        }
        
        // Delimiter tespiti
        $first_line = fgets($file);
        rewind($file);
        if ($bom === "\xEF\xBB\xBF") {
            fread($file, 3);
        }
        
        $delimiters = [';', ',', "\t"];
        $delimiter = ';';
        $max_count = 0;
        
        foreach ($delimiters as $delim) {
            $count = substr_count($first_line, $delim);
            if ($count > $max_count) {
                $max_count = $count;
                $delimiter = $delim;
            }
        }
        
        $headers = fgetcsv($file, 0, $delimiter);
        $chunk = [];
        $row_count = 0;
        
        while (($row = fgetcsv($file, 0, $delimiter)) !== false) {
            $chunk[] = $row;
            $row_count++;
            
            if (count($chunk) >= $chunk_size) {
                call_user_func($chunk_callback, $chunk, $headers);
                $chunk = [];
                
                // Memory temizliği
                if ($row_count % 1000 === 0) {
                    if (function_exists('gc_collect_cycles')) {
                        gc_collect_cycles();
                    }
                }
            }
        }
        
        // Son chunk'ı işle
        if (!empty($chunk)) {
            call_user_func($chunk_callback, $chunk, $headers);
        }
        
        fclose($file);
        return $row_count;
    }
    
    /**
     * Excel dosyasını chunk halinde okur
     */
    private static function read_excel_in_chunks($file_path, $chunk_callback, $chunk_size) {
        if (!function_exists('read_excel_file')) {
            throw new Exception('Excel okuma fonksiyonu bulunamadı');
        }
        
        // Excel'i tamamen memory'e yüklemek yerine, 
        // büyük dosyalar için özel okuma stratejisi kullanılabilir
        $data = read_excel_file($file_path);
        $headers = array_shift($data);
        
        $chunks = array_chunk($data, $chunk_size);
        foreach ($chunks as $chunk) {
            call_user_func($chunk_callback, $chunk, $headers);
        }
        
        return count($data);
    }
}

/**
 * AJAX handler for progress tracking
 */
function handle_import_progress_ajax() {
    if (!isset($_POST['session_id'])) {
        wp_die('Session ID gerekli');
    }
    
    $session_id = sanitize_text_field($_POST['session_id']);
    $processor = new ImportBatchProcessor($session_id);
    $status = $processor->get_status();
    
    wp_send_json($status);
}

// AJAX hook'larını ekle
add_action('wp_ajax_import_progress', 'handle_import_progress_ajax');
add_action('wp_ajax_nopriv_import_progress', 'handle_import_progress_ajax');

/**
 * Backup oluşturma fonksiyonu
 */
function create_import_backup($table_names = []) {
    global $wpdb;
    
    if (empty($table_names)) {
        $table_names = [
            $wpdb->prefix . 'insurance_crm_customers',
            $wpdb->prefix . 'insurance_crm_policies'
        ];
    }
    
    $backup_dir = wp_upload_dir()['basedir'] . '/crm_backups';
    if (!file_exists($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    $backup_file = $backup_dir . '/backup_' . date('Y-m-d_H-i-s') . '.sql';
    $backup_content = "-- Insurance CRM Backup " . date('Y-m-d H:i:s') . "\n\n";
    
    foreach ($table_names as $table) {
        // Tablo yapısını al
        $create_table = $wpdb->get_row("SHOW CREATE TABLE $table", ARRAY_N);
        $backup_content .= "DROP TABLE IF EXISTS `$table`;\n";
        $backup_content .= $create_table[1] . ";\n\n";
        
        // Verileri al
        $rows = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);
        
        if (!empty($rows)) {
            $backup_content .= "INSERT INTO `$table` VALUES \n";
            $values = [];
            
            foreach ($rows as $row) {
                $escaped_values = array_map(function($value) use ($wpdb) {
                    return $value === null ? 'NULL' : "'" . $wpdb->_escape($value) . "'";
                }, array_values($row));
                $values[] = '(' . implode(',', $escaped_values) . ')';
            }
            
            $backup_content .= implode(",\n", $values) . ";\n\n";
        }
    }
    
    file_put_contents($backup_file, $backup_content);
    
    return $backup_file;
}

/**
 * Memory kullanımını optimize eder
 */
function optimize_memory_for_import() {
    // Memory limit'i artır
    $current_limit = ini_get('memory_limit');
    $current_bytes = wp_convert_hr_to_bytes($current_limit);
    $recommended_bytes = 256 * 1024 * 1024; // 256MB
    
    if ($current_bytes < $recommended_bytes) {
        ini_set('memory_limit', '256M');
    }
    
    // Execution time'ı artır
    set_time_limit(300); // 5 dakika
    
    // Garbage collection'ı etkinleştir
    if (function_exists('gc_enable')) {
        gc_enable();
    }
}