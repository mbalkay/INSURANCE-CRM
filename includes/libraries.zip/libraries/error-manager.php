<?php
/**
 * Error Management and Export System for Import Operations
 * 
 * @package Insurance_CRM
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Import hata yönetimi ve raporlama
 */
class ImportErrorManager {
    
    private $wpdb;
    private $error_table;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->error_table = $wpdb->prefix . 'insurance_crm_import_errors';
        $this->create_error_table();
    }
    
    /**
     * Hata tablosunu oluşturur
     */
    private function create_error_table() {
        $charset_collate = $this->wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->error_table} (
            id int(11) NOT NULL AUTO_INCREMENT,
            import_session varchar(100) NOT NULL,
            row_number int(11) NOT NULL,
            field_name varchar(100) DEFAULT NULL,
            field_value text DEFAULT NULL,
            error_type varchar(50) NOT NULL,
            error_message text NOT NULL,
            suggestion text DEFAULT NULL,
            severity enum('error', 'warning', 'info') DEFAULT 'error',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY import_session (import_session),
            KEY error_type (error_type),
            KEY severity (severity)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Hata kaydeder
     */
    public function log_error($session_id, $row_number, $field_name, $field_value, $error_type, $error_message, $suggestion = null, $severity = 'error') {
        $this->wpdb->insert(
            $this->error_table,
            [
                'import_session' => $session_id,
                'row_number' => $row_number,
                'field_name' => $field_name,
                'field_value' => $field_value,
                'error_type' => $error_type,
                'error_message' => $error_message,
                'suggestion' => $suggestion,
                'severity' => $severity,
                'created_at' => current_time('mysql')
            ]
        );
    }
    
    /**
     * Session'ın hatalarını getirir
     */
    public function get_session_errors($session_id, $severity = null) {
        $where = "import_session = %s";
        $params = [$session_id];
        
        if ($severity) {
            $where .= " AND severity = %s";
            $params[] = $severity;
        }
        
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->error_table} WHERE $where ORDER BY row_number, field_name",
            $params
        ), ARRAY_A);
    }
    
    /**
     * Hataları Excel formatında export eder
     */
    public function export_errors_to_excel($session_id, $include_suggestions = true) {
        $errors = $this->get_session_errors($session_id);
        
        if (empty($errors)) {
            throw new Exception('Bu session için hata bulunamadı.');
        }
        
        // Excel export fonksiyonunu kullan
        if (!function_exists('insurance_crm_export_excel')) {
            require_once dirname(__DIR__) . '/excel-exporter.php';
        }
        
        $title = 'Import Hataları - ' . date('Y-m-d H:i:s');
        
        insurance_crm_export_excel($title, function($spreadsheet) use ($errors, $include_suggestions) {
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Import Hataları');
            
            // Başlıkları ayarla
            $headers = ['Satır No', 'Alan Adı', 'Değer', 'Hata Tipi', 'Hata Mesajı', 'Önem Derecesi'];
            if ($include_suggestions) {
                $headers[] = 'Öneri';
            }
            $headers[] = 'Tarih';
            
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . '1', $header);
                $sheet->getStyle($col . '1')->getFont()->setBold(true);
                $col++;
            }
            
            // Verileri ekle
            $row = 2;
            foreach ($errors as $error) {
                $sheet->setCellValue('A' . $row, $error['row_number']);
                $sheet->setCellValue('B' . $row, $error['field_name'] ?: 'Genel');
                $sheet->setCellValue('C' . $row, $error['field_value']);
                $sheet->setCellValue('D' . $row, $error['error_type']);
                $sheet->setCellValue('E' . $row, $error['error_message']);
                $sheet->setCellValue('F' . $row, ucfirst($error['severity']));
                
                $col_index = 'G';
                if ($include_suggestions) {
                    $sheet->setCellValue($col_index . $row, $error['suggestion'] ?: '');
                    $col_index++;
                }
                $sheet->setCellValue($col_index . $row, $error['created_at']);
                
                // Severity'ye göre renklendirme
                $style = $sheet->getStyle('A' . $row . ':' . $col_index . $row);
                switch ($error['severity']) {
                    case 'error':
                        $style->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
                        $style->getFill()->getStartColor()->setRGB('FFEBEE');
                        break;
                    case 'warning':
                        $style->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
                        $style->getFill()->getStartColor()->setRGB('FFF3E0');
                        break;
                }
                
                $row++;
            }
            
            // Sütun genişliklerini ayarla
            foreach (range('A', $col_index) as $column) {
                $sheet->getColumnDimension($column)->setAutoSize(true);
            }
        });
    }
    
    /**
     * Hatalar için düzeltme önerileri oluşturur
     */
    public function generate_suggestions($error_type, $field_name, $field_value) {
        $suggestions = [];
        
        switch ($error_type) {
            case 'tc_kimlik_invalid':
                $suggestions[] = 'TC Kimlik numarası 11 haneli olmalı ve geçerli bir algoritma kontrolünden geçmelidir.';
                $suggestions[] = 'Örnek geçerli format: 12345678901';
                if (strlen($field_value) !== 11) {
                    $suggestions[] = 'Mevcut değer ' . strlen($field_value) . ' haneli, 11 hane olmalı.';
                }
                break;
                
            case 'phone_invalid':
                $suggestions[] = 'Telefon numarası 0 ile başlamalı ve 10-11 haneli olmalıdır.';
                $suggestions[] = 'Cep telefonu: 05XXXXXXXXX (11 hane)';
                $suggestions[] = 'Sabit hat: 0XXXXXXXXX (10 hane)';
                break;
                
            case 'email_invalid':
                $suggestions[] = 'Email formatı: kullanici@domain.com şeklinde olmalıdır.';
                $suggestions[] = 'Boşluk, Türkçe karakter ve özel simgeler kullanmayın.';
                break;
                
            case 'date_invalid':
                $suggestions[] = 'Desteklenen tarih formatları:';
                $suggestions[] = '• DD.MM.YYYY (15.03.1985)';
                $suggestions[] = '• DD/MM/YYYY (15/03/1985)';
                $suggestions[] = '• YYYY-MM-DD (1985-03-15)';
                break;
                
            case 'currency_invalid':
                $suggestions[] = 'Para birimi formatları:';
                $suggestions[] = '• 1.000,50 (Türkçe format)';
                $suggestions[] = '• 1000.50 (İngilizce format)';
                $suggestions[] = '• Sadece rakam: 1000';
                break;
                
            case 'required_field_empty':
                $suggestions[] = "'{$field_name}' alanı zorunludur ve boş bırakılamaz.";
                $suggestions[] = 'Bu alan için geçerli bir değer girin.';
                break;
                
            default:
                $suggestions[] = 'Lütfen veriyi kontrol edin ve düzeltin.';
        }
        
        return implode(' ', $suggestions);
    }
    
    /**
     * Hata istatistiklerini getirir
     */
    public function get_error_statistics($session_id) {
        $stats = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT 
                error_type,
                severity,
                COUNT(*) as error_count,
                COUNT(DISTINCT row_number) as affected_rows
             FROM {$this->error_table} 
             WHERE import_session = %s 
             GROUP BY error_type, severity
             ORDER BY error_count DESC",
            $session_id
        ), ARRAY_A);
        
        $summary = [
            'total_errors' => 0,
            'total_rows_with_errors' => 0,
            'by_severity' => ['error' => 0, 'warning' => 0, 'info' => 0],
            'by_type' => [],
            'details' => $stats
        ];
        
        foreach ($stats as $stat) {
            $summary['total_errors'] += $stat['error_count'];
            $summary['by_severity'][$stat['severity']] += $stat['error_count'];
            $summary['by_type'][$stat['error_type']] = ($summary['by_type'][$stat['error_type']] ?? 0) + $stat['error_count'];
        }
        
        // Toplam hatalı satır sayısını al
        $summary['total_rows_with_errors'] = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(DISTINCT row_number) FROM {$this->error_table} WHERE import_session = %s",
            $session_id
        ));
        
        return $summary;
    }
    
    /**
     * Eski hataları temizler
     */
    public function cleanup_old_errors($days = 30) {
        return $this->wpdb->query($this->wpdb->prepare(
            "DELETE FROM {$this->error_table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
    }
}

/**
 * AJAX handler for error export
 */
function handle_export_import_errors_ajax() {
    if (!isset($_POST['session_id'])) {
        wp_die('Session ID gerekli');
    }
    
    $session_id = sanitize_text_field($_POST['session_id']);
    $include_suggestions = isset($_POST['include_suggestions']) && $_POST['include_suggestions'] === 'true';
    
    try {
        $error_manager = new ImportErrorManager();
        $error_manager->export_errors_to_excel($session_id, $include_suggestions);
    } catch (Exception $e) {
        wp_die('Hata export edilirken sorun oluştu: ' . $e->getMessage());
    }
}

// AJAX hook
add_action('wp_ajax_export_import_errors', 'handle_export_import_errors_ajax');

/**
 * Validation error helper - kolayca hata loglamak için
 */
function log_import_validation_error($session_id, $row_number, $field_name, $field_value, $error_message, $error_type = 'validation_error') {
    $error_manager = new ImportErrorManager();
    $suggestion = $error_manager->generate_suggestions($error_type, $field_name, $field_value);
    $error_manager->log_error($session_id, $row_number, $field_name, $field_value, $error_type, $error_message, $suggestion);
}